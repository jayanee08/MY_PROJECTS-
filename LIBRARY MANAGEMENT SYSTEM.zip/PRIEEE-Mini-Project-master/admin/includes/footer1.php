<footer class="dark footer section">
<div class="container">
<div class="row">
<div class="col-md-3 col-md-6 col-xs-12">
<div class="widget">
<div class="widget-title">

</div>
</div>
<div class="col-md-3 col-md-6 col-xs-12">

</div>
<div class="col-md-3 col-md-6 col-xs-12">

</div>
<div class="col-md-3 col-md-6 col-xs-12">
<div class="widget">
<div class="widget-title">



</div>
</div>
</div>
</footer>